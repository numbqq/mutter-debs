/*
 * Cogl
 *
 * A Low Level GPU Graphics and Utilities API
 *
 * Copyright (C) 2007,2008,2009,2010 Intel Corporation.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#include <poll.h>

#define COGL_SYSDEF_POLLIN POLLIN
#define COGL_SYSDEF_POLLPRI POLLPRI
#define COGL_SYSDEF_POLLOUT POLLOUT
#define COGL_SYSDEF_POLLERR POLLERR
#define COGL_SYSDEF_POLLHUP POLLHUP
#define COGL_SYSDEF_POLLNVAL POLLNVAL

#define COGL_HAS_GL
#define CLUTTER_COGL_HAS_GL
#define COGL_HAS_GLX_SUPPORT
#define COGL_HAS_EGL_PLATFORM_XLIB_SUPPORT
#define COGL_HAS_EGL_SUPPORT
#define COGL_HAS_X11
#define COGL_HAS_XLIB

#define COGL_HAS_TRACING
